# API de Pão de Queijo

## Sobre o projeto
Este trabalho é uma API para uma loja de pão de queijo. O site consulta os produtos pela API e envia os pedidos para o servidor.

## Tecnologias
- HTML, CSS e JavaScript
- Node.js (módulo HTTP nativo)
- JSON para armazenar os pedidos

## Como executar
1. Instale o Node.js.
2. Abra a pasta do projeto no VS Code.
3. No terminal, execute `npm start`.
4. Abra `http://localhost:3000` no navegador.

## Rotas da API

| Método | Rota | Função |
|---|---|---|
| GET | `/api/health` | Verifica se a API está funcionando |
| GET | `/api/products` | Lista todos os produtos |
| GET | `/api/products/:id` | Busca um produto pelo ID |
| GET | `/api/orders` | Lista os pedidos |
| GET | `/api/orders/:id` | Busca um pedido pelo ID |
| POST | `/api/orders` | Cadastra um novo pedido |

### Exemplo de corpo para criar pedido
```json
{
  "nome": "Ana",
  "telefone": "11999999999",
  "tipoEntrega": "Retirada",
  "observacao": "",
  "itens": [
    { "id": 1, "quantidade": 2 }
  ]
}
```

## Testes
Execute `npm test`.

## Observação
Os pedidos são gravados no arquivo `data/pedidos.json`, criado automaticamente quando o primeiro pedido é registrado. É um projeto escolar demonstrativo e não processa pagamentos.

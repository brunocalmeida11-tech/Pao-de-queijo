import test from "node:test";
import assert from "node:assert/strict";
import { PredictiveEngine } from "./js/PredictiveEngine.js";
import { LateTracker } from "./js/LateTracker.js";
import { QrManager } from "./js/QrManager.js";

test("a previsão coloca primeiro o produto mais pedido", () => {
  const motor = new PredictiveEngine();
  const produtos = [{ id: 1 }, { id: 2 }];
  const pedidos = [{ itens: [{ id: 2, quantidade: 3 }, { id: 1, quantidade: 1 }] }];
  assert.deepEqual(motor.ordenarPorPopularidade(produtos, pedidos).map(p => p.id), [2, 1]);
});
test("o acompanhamento encontra um pedido pelo ID", () => {
  const tracker = new LateTracker([{ id: 2, nome: "Ana" }]);
  assert.equal(tracker.encontrar(2).nome, "Ana");
  assert.equal(tracker.encontrar(8), null);
});
test("o QR gera os dados principais em JSON", () => {
  const qr = new QrManager();
  assert.equal(JSON.parse(qr.dadosPedido({ id: 3, total: 12, status: "Recebido" })).total, 12);
});

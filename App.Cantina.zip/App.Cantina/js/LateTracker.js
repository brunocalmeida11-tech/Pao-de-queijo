// Funções de acompanhamento de pedidos usadas pelo projeto.
export class LateTracker {
  constructor(pedidos = []) { this.pedidos = pedidos; }
  listar() { return [...this.pedidos]; }
  encontrar(id) { return this.pedidos.find(p => p.id === Number(id)) || null; }
}

import { PredictiveEngine } from "./PredictiveEngine.js";
import { LateTracker } from "./LateTracker.js";
import { QrManager } from "./QrManager.js";

const API_BASE = "http://localhost:3000/api";
const CART_STORAGE_KEY = "pao_de_queijo_carrinho";
const USER_ORDERS_KEY = "pao_de_queijo_meus_pedidos";

export const IMAGENS_PRODUTOS = {
  1: "img/pao_tradicional.jpg",
  2: "img/pao_recheado.jpg",
  3: "img/combo_seis.jpg",
  4: "img/pao_mini.jpg",
  5: "img/combo_cafe.jpg",
  6: "img/pao_especial.jpg"
};

// ============================================================================
// Utilitários de Formatação e Interface
// ============================================================================
export const formatarMoeda = valor =>
  Number(valor || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export const escapar = texto =>
  String(texto || "").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[c]));

export const formatarData = isoString => {
  if (!isoString) return "";
  const data = new Date(isoString);
  return data.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
};

// ============================================================================
// Toast de Notificações
// ============================================================================
export function mostrarToast(mensagem, tipo = "sucesso") {
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = `toast ${tipo}`;
  const icone = tipo === "sucesso" ? "✅" : tipo === "erro" ? "⚠️" : "ℹ️";
  toast.innerHTML = `<span>${icone}</span><span>${escapar(mensagem)}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(-10px)";
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

// ============================================================================
// Gerenciador do Carrinho (Persistente em LocalStorage)
// ============================================================================
export const Carrinho = {
  obter() {
    try {
      const salvo = localStorage.getItem(CART_STORAGE_KEY);
      return salvo ? JSON.parse(salvo) : [];
    } catch {
      return [];
    }
  },

  salvar(itens) {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(itens));
    this.atualizarInterface();
  },

  adicionar(produto, quantidade = 1) {
    const itens = this.obter();
    const index = itens.findIndex(i => i.id === produto.id);
    if (index >= 0) {
      itens[index].quantidade += quantidade;
    } else {
      itens.push({
        id: produto.id,
        nome: produto.nome,
        preco: produto.preco,
        icone: produto.icone || "🧀",
        imagem: produto.imagem || "img/pao_tradicional.jpg",
        quantidade
      });
    }
    this.salvar(itens);
    mostrarToast(`"${produto.nome}" adicionado ao pedido!`);
  },

  alterarQuantidade(id, delta) {
    let itens = this.obter();
    const item = itens.find(i => i.id === id);
    if (!item) return;

    item.quantidade += delta;
    if (item.quantidade <= 0) {
      itens = itens.filter(i => i.id !== id);
    }
    this.salvar(itens);
  },

  remover(id) {
    const itens = this.obter().filter(i => i.id !== id);
    this.salvar(itens);
    mostrarToast("Item removido do pedido.", "info");
  },

  limpar() {
    localStorage.removeItem(CART_STORAGE_KEY);
    this.atualizarInterface();
  },

  totais(taxaEntrega = 0) {
    const itens = this.obter();
    const quantidadeTotal = itens.reduce((acc, i) => acc + i.quantidade, 0);
    const subtotal = itens.reduce((acc, i) => acc + (i.preco * i.quantidade), 0);
    const total = subtotal + taxaEntrega;
    return { quantidadeTotal, subtotal, total };
  },

  atualizarInterface() {
    const { quantidadeTotal, subtotal } = this.totais();
    
    // Atualiza badges em qualquer página
    document.querySelectorAll(".badge-contador").forEach(badge => {
      badge.textContent = quantidadeTotal;
      badge.classList.remove("badge-bounce");
      void badge.offsetWidth; // trigger reflow
      badge.classList.add("badge-bounce");
    });

    const contadorTexto = document.getElementById("contador-carrinho");
    if (contadorTexto) {
      contadorTexto.textContent = `${quantidadeTotal} ${quantidadeTotal === 1 ? "item" : "itens"}`;
    }

    // Atualiza barra flutuante se presente
    const barraFlutuante = document.getElementById("barra-flutuante");
    if (barraFlutuante) {
      if (quantidadeTotal > 0) {
        barraFlutuante.classList.add("visivel");
        const precoEl = barraFlutuante.querySelector(".flutuante-preco");
        const qtdEl = barraFlutuante.querySelector(".flutuante-qtd");
        if (precoEl) precoEl.textContent = formatarMoeda(subtotal);
        if (qtdEl) qtdEl.textContent = `${quantidadeTotal} ${quantidadeTotal === 1 ? "item" : "itens"}`;
      } else {
        barraFlutuante.classList.remove("visivel");
      }
    }
  }
};

// ============================================================================
// Histórico Local de Pedidos do Cliente
// ============================================================================
export const HistoricoLocal = {
  obter() {
    try {
      const salvo = localStorage.getItem(USER_ORDERS_KEY);
      return salvo ? JSON.parse(salvo) : [];
    } catch {
      return [];
    }
  },
  adicionar(pedido) {
    const pedidos = this.obter();
    pedidos.unshift(pedido);
    localStorage.setItem(USER_ORDERS_KEY, JSON.stringify(pedidos.slice(0, 20)));
  }
};

// ============================================================================
// Requisições à API
// ============================================================================
export async function requisicaoAPI(caminho, opcoes = {}) {
  const url = `${API_BASE}${caminho}`;
  const res = await fetch(url, {
    ...opcoes,
    headers: {
      "Content-Type": "application/json",
      ...(opcoes.headers || {})
    }
  });
  const dados = await res.json();
  if (!res.ok) {
    throw new Error(dados.erro || "Falha ao comunicar com a API.");
  }
  return dados;
}

// ============================================================================
// Gerador Visual de QR Code (SVG nativo autônomo de alta fidelidade)
// ============================================================================
export function renderizarQRCodeSVG(texto) {
  // Gera um padrão matricial pseudo-QR determinístico estilizado baseado no payload
  let hash = 0;
  for (let i = 0; i < texto.length; i++) {
    hash = ((hash << 5) - hash) + texto.charCodeAt(i);
    hash |= 0;
  }
  
  const tamanho = 21; // Matriz 21x21 como padrão QR Version 1
  const celula = 8;
  const dimensao = tamanho * celula;
  
  // Função para saber se a posição é um marcador de posição fixo nos cantos
  const ehMarcador = (x, y) => {
    if ((x < 7 && y < 7) || (x >= tamanho - 7 && y < 7) || (x < 7 && y >= tamanho - 7)) {
      const dx = x < 7 ? x : x - (tamanho - 7);
      const dy = y < 7 ? y : y - (tamanho - 7);
      if (dx === 0 || dx === 6 || dy === 0 || dy === 6) return true;
      if (dx >= 2 && dx <= 4 && dy >= 2 && dy <= 4) return true;
      return false;
    }
    return null;
  };

  let rects = "";
  for (let y = 0; y < tamanho; y++) {
    for (let x = 0; x < tamanho; x++) {
      const marcador = ehMarcador(x, y);
      let preenchido = false;
      if (marcador !== null) {
        preenchido = marcador;
      } else {
        const val = Math.abs(Math.sin(hash + x * 13 + y * 29));
        preenchido = val > 0.48;
      }

      if (preenchido) {
        rects += `<rect x="${x * celula}" y="${y * celula}" width="${celula}" height="${celula}" fill="#1b3d2b" rx="1.5" />`;
      }
    }
  }

  return `
    <svg width="${dimensao}" height="${dimensao}" viewBox="0 0 ${dimensao} ${dimensao}" xmlns="http://www.w3.org/2000/svg">
      <rect width="${dimensao}" height="${dimensao}" fill="#ffffff" />
      ${rects}
    </svg>
  `;
}

// ============================================================================
// Controle do Modal de QR Code
// ============================================================================
export function configurarModalQR() {
  const modal = document.getElementById("modal-qr");
  if (!modal) return;

  const btnFechar = modal.querySelector(".btn-fechar-modal");
  if (btnFechar) {
    btnFechar.addEventListener("click", () => modal.classList.remove("aberto"));
  }

  modal.addEventListener("click", e => {
    if (e.target === modal) modal.classList.remove("aberto");
  });

  const btnCopiar = document.getElementById("btn-copiar-qr-json");
  if (btnCopiar) {
    btnCopiar.addEventListener("click", () => {
      const jsonText = document.getElementById("qr-dados-json")?.textContent;
      if (jsonText) {
        navigator.clipboard.writeText(jsonText).then(() => {
          mostrarToast("Dados do QR Code copiados para a área de transferência!");
        });
      }
    });
  }
}

export function abrirModalQR(pedido) {
  const modal = document.getElementById("modal-qr");
  if (!modal) return;

  const qrManager = new QrManager();
  const dadosStr = qrManager.dadosPedido(pedido);

  const containerSVG = document.getElementById("qr-svg-container");
  if (containerSVG) {
    containerSVG.innerHTML = renderizarQRCodeSVG(dadosStr);
  }

  const jsonBox = document.getElementById("qr-dados-json");
  if (jsonBox) {
    jsonBox.textContent = JSON.stringify(JSON.parse(dadosStr), null, 2);
  }

  const tituloEl = document.getElementById("modal-qr-titulo");
  if (tituloEl) {
    tituloEl.textContent = `Pedido #${pedido.id}`;
  }

  modal.classList.add("aberto");
}

// ============================================================================
// Inicializador: Página Inicial (index.html)
// ============================================================================
export async function iniciarHome() {
  Carrinho.atualizarInterface();
  const containerDestaques = document.getElementById("destaques-produtos");
  if (!containerDestaques) return;

  try {
    const [resProd, resPed] = await Promise.all([
      requisicaoAPI("/products"),
      requisicaoAPI("/orders").catch(() => ({ pedidos: [] }))
    ]);

    const produtos = resProd.produtos.map(p => ({
      ...p,
      imagem: p.imagem || IMAGENS_PRODUTOS[p.id] || "img/pao_tradicional.jpg"
    }));

    const predictive = new PredictiveEngine();
    const produtosOrdenados = predictive.ordenarPorPopularidade(produtos, resPed.pedidos);
    const top3 = produtosOrdenados.slice(0, 3);

    containerDestaques.innerHTML = top3.map((p, index) => `
      <article class="card-produto">
        <div class="produto-foto-wrapper">
          <img src="${p.imagem || 'img/pao_tradicional.jpg'}" alt="${escapar(p.nome)}" class="produto-foto" loading="lazy">
          <span class="badge-destaque ${index === 0 ? "" : "badge-popular"}">
            ${index === 0 ? "🔥 #1 Mais Pedido" : index === 1 ? "⭐ Favorito" : "✨ Destaque"}
          </span>
        </div>
        <h3>${escapar(p.nome)}</h3>
        <p class="descricao">${escapar(p.descricao)}</p>
        <div class="card-produto-rodape">
          <div>
            <span class="preco-rotulo">Preço Unitário</span>
            <span class="preco-valor">${formatarMoeda(p.preco)}</span>
          </div>
          <button class="btn-adicionar" data-adicionar-id="${p.id}">
            <span>+</span> Adicionar
          </button>
        </div>
      </article>
    `).join("");

    containerDestaques.querySelectorAll("[data-adicionar-id]").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = Number(btn.dataset.adicionarId);
        const produto = resProd.produtos.find(x => x.id === id);
        if (produto) Carrinho.adicionar(produto);
      });
    });

  } catch (erro) {
    containerDestaques.innerHTML = `
      <div class="estado-vazio" style="grid-column: 1/-1;">
        <span class="icone-vazio">⚠️</span>
        <h3>Não foi possível carregar os destaques</h3>
        <p>Verifique se o servidor está rodando com <code>npm start</code>.</p>
      </div>
    `;
  }
}

// ============================================================================
// Inicializador: Página Cardápio (cardapio.html)
// ============================================================================
export async function iniciarCardapio() {
  Carrinho.atualizarInterface();
  const listaEl = document.getElementById("lista-cardapio");
  const inputBusca = document.getElementById("input-busca");
  const selectOrdenacao = document.getElementById("select-ordenacao");
  const pillsFiltro = document.querySelectorAll("[data-categoria]");

  if (!listaEl) return;

  let produtosOriginais = [];
  let pedidosOriginais = [];
  let filtroCategoria = "todos";
  let termoBusca = "";
  let criterioOrdenacao = "popularidade";

  const renderizar = () => {
    let filtrados = [...produtosOriginais];

    // Busca textual
    if (termoBusca) {
      const termo = termoBusca.toLowerCase();
      filtrados = filtrados.filter(p =>
        p.nome.toLowerCase().includes(termo) ||
        p.descricao.toLowerCase().includes(termo)
      );
    }

    // Filtro de categoria
    if (filtroCategoria === "tradicionais") {
      filtrados = filtrados.filter(p => p.nome.toLowerCase().includes("tradicional") || p.nome.toLowerCase().includes("mini"));
    } else if (filtroCategoria === "recheados") {
      filtrados = filtrados.filter(p => p.nome.toLowerCase().includes("recheado") || p.nome.toLowerCase().includes("especial"));
    } else if (filtroCategoria === "combos") {
      filtrados = filtrados.filter(p => p.nome.toLowerCase().includes("combo"));
    }

    // Ordenação
    if (criterioOrdenacao === "popularidade") {
      const predictive = new PredictiveEngine();
      filtrados = predictive.ordenarPorPopularidade(filtrados, pedidosOriginais);
    } else if (criterioOrdenacao === "menor-preco") {
      filtrados.sort((a, b) => a.preco - b.preco);
    } else if (criterioOrdenacao === "maior-preco") {
      filtrados.sort((a, b) => b.preco - a.preco);
    } else if (criterioOrdenacao === "nome") {
      filtrados.sort((a, b) => a.nome.localeCompare(b.nome));
    }

    if (filtrados.length === 0) {
      listaEl.innerHTML = `
        <div class="estado-vazio" style="grid-column: 1/-1;">
          <span class="icone-vazio">🔍</span>
          <h3>Nenhum pão de queijo encontrado</h3>
          <p>Tente buscar com outras palavras ou alterar o filtro.</p>
        </div>
      `;
      return;
    }

    listaEl.innerHTML = filtrados.map(p => `
      <article class="card-produto">
        <div class="produto-foto-wrapper">
          <img src="${p.imagem || 'img/pao_tradicional.jpg'}" alt="${escapar(p.nome)}" class="produto-foto" loading="lazy">
          ${p.preco >= 15 ? '<span class="badge-destaque badge-popular">🌟 Combo Especial</span>' : ''}
        </div>
        <h3>${escapar(p.nome)}</h3>
        <p class="descricao">${escapar(p.descricao)}</p>
        <div class="card-produto-rodape">
          <div>
            <span class="preco-rotulo">Preço Unitário</span>
            <span class="preco-valor">${formatarMoeda(p.preco)}</span>
          </div>
          <button class="btn-adicionar" data-adicionar-id="${p.id}">
            <span>+</span> Adicionar
          </button>
        </div>
      </article>
    `).join("");

    listaEl.querySelectorAll("[data-adicionar-id]").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = Number(btn.dataset.adicionarId);
        const produto = produtosOriginais.find(x => x.id === id);
        if (produto) Carrinho.adicionar(produto);
      });
    });
  };

  try {
    const [resProd, resPed] = await Promise.all([
      requisicaoAPI("/products"),
      requisicaoAPI("/orders").catch(() => ({ pedidos: [] }))
    ]);
    produtosOriginais = resProd.produtos.map(p => ({
      ...p,
      imagem: p.imagem || IMAGENS_PRODUTOS[p.id] || "img/pao_tradicional.jpg"
    }));
    pedidosOriginais = resPed.pedidos;
    renderizar();
  } catch (erro) {
    listaEl.innerHTML = `
      <div class="estado-vazio" style="grid-column: 1/-1;">
        <span class="icone-vazio">⚠️</span>
        <h3>Erro ao carregar o cardápio</h3>
        <p>${escapar(erro.message)}</p>
      </div>
    `;
  }

  if (inputBusca) {
    inputBusca.addEventListener("input", e => {
      termoBusca = e.target.value.trim();
      renderizar();
    });
  }

  if (selectOrdenacao) {
    selectOrdenacao.addEventListener("change", e => {
      criterioOrdenacao = e.target.value;
      renderizar();
    });
  }

  pillsFiltro.forEach(pill => {
    pill.addEventListener("click", () => {
      pillsFiltro.forEach(p => p.classList.remove("ativo"));
      pill.classList.add("ativo");
      filtroCategoria = pill.dataset.categoria;
      renderizar();
    });
  });
}

// ============================================================================
// Inicializador: Página Meu Pedido / Checkout (meus-pedidos.html)
// ============================================================================
export function iniciarMeuPedido() {
  Carrinho.atualizarInterface();
  configurarModalQR();

  const listaItensEl = document.getElementById("lista-itens-carrinho");
  const subtotalEl = document.getElementById("resumo-subtotal");
  const taxaEntregaEl = document.getElementById("resumo-taxa");
  const totalEl = document.getElementById("resumo-total");
  const formPedido = document.getElementById("form-pedido");
  const grupoEndereco = document.getElementById("grupo-endereco");
  const radiosEntrega = document.querySelectorAll("input[name='tipoEntrega']");
  const listaRecentesEl = document.getElementById("lista-pedidos-recentes");

  let taxaEntrega = 0;

  const renderizarCarrinho = () => {
    const itens = Carrinho.obter();
    const { subtotal, total, quantidadeTotal } = Carrinho.totais(taxaEntrega);

    if (subtotalEl) subtotalEl.textContent = formatarMoeda(subtotal);
    if (taxaEntregaEl) taxaEntregaEl.textContent = taxaEntrega === 0 ? "Grátis" : formatarMoeda(taxaEntrega);
    if (totalEl) totalEl.textContent = formatarMoeda(total);

    const btnEnviar = document.getElementById("btn-finalizar-pedido");
    if (btnEnviar) {
      btnEnviar.disabled = itens.length === 0;
    }

    if (!listaItensEl) return;

    if (itens.length === 0) {
      listaItensEl.innerHTML = `
        <div class="estado-vazio">
          <span class="icone-vazio">🧺</span>
          <h3>Seu carrinho está vazio</h3>
          <p>Adicione deliciosos pães de queijo do nosso cardápio!</p>
          <a href="cardapio.html" class="botao botao-dourado botao-pequeno" style="margin-top: 14px;">
            Ver Cardápio
          </a>
        </div>
      `;
      return;
    }

    listaItensEl.innerHTML = itens.map(item => `
      <div class="item-carrinho">
        <div class="item-carrinho-info">
          <img src="${item.imagem || 'img/pao_tradicional.jpg'}" alt="${escapar(item.nome)}" class="item-carrinho-foto">
          <div>
            <h4>${escapar(item.nome)}</h4>
            <small>${formatarMoeda(item.preco)} cada</small>
          </div>
        </div>
        <div class="controles-quantidade">
          <button class="btn-qtd" data-qtd-menos="${item.id}">−</button>
          <span class="qtd-valor">${item.quantidade}</span>
          <button class="btn-qtd" data-qtd-mais="${item.id}">+</button>
        </div>
        <strong style="min-width: 75px; text-align: right; color: var(--green-dark);">
          ${formatarMoeda(item.preco * item.quantidade)}
        </strong>
        <button class="btn-remover-item" data-remover="${item.id}" title="Remover item">
          🗑️
        </button>
      </div>
    `).join("");

    listaItensEl.querySelectorAll("[data-qtd-menos]").forEach(btn => {
      btn.addEventListener("click", () => {
        Carrinho.alterarQuantidade(Number(btn.dataset.qtdMenos), -1);
        renderizarCarrinho();
      });
    });

    listaItensEl.querySelectorAll("[data-qtd-mais]").forEach(btn => {
      btn.addEventListener("click", () => {
        Carrinho.alterarQuantidade(Number(btn.dataset.qtdMais), 1);
        renderizarCarrinho();
      });
    });

    listaItensEl.querySelectorAll("[data-remover]").forEach(btn => {
      btn.addEventListener("click", () => {
        Carrinho.remover(Number(btn.dataset.remover));
        renderizarCarrinho();
      });
    });
  };

  const renderizarRecentes = () => {
    if (!listaRecentesEl) return;
    const recentes = HistoricoLocal.obter();
    if (recentes.length === 0) {
      listaRecentesEl.innerHTML = `
        <div class="estado-vazio" style="padding: 24px;">
          <p>Você ainda não realizou pedidos neste dispositivo.</p>
        </div>
      `;
      return;
    }

    listaRecentesEl.innerHTML = recentes.map(p => `
      <div class="item-carrinho" style="background: #ffffff;">
        <div class="item-carrinho-info">
          <div class="item-carrinho-icone">📦</div>
          <div>
            <h4>Pedido #${p.id} — ${formatarMoeda(p.total)}</h4>
            <small>${p.tipoEntrega} • ${formatarData(p.criadoEm)}</small>
          </div>
        </div>
        <div style="display: flex; gap: 8px;">
          <span class="status-badge status-recebido">
            <span class="status-ponto"></span>${escapar(p.status || "Recebido")}
          </span>
          <button class="botao botao-outline botao-pequeno" data-ver-qr-recente="${p.id}">
            QR Code
          </button>
        </div>
      </div>
    `).join("");

    listaRecentesEl.querySelectorAll("[data-ver-qr-recente]").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = Number(btn.dataset.verQrRecente);
        const pedido = recentes.find(x => x.id === id);
        if (pedido) abrirModalQR(pedido);
      });
    });
  };

  // Alternância do tipo de entrega
  radiosEntrega.forEach(radio => {
    radio.addEventListener("change", e => {
      document.querySelectorAll(".opcao-radio-card").forEach(c => c.classList.remove("selecionado"));
      radio.closest(".opcao-radio-card")?.classList.add("selecionado");

      if (e.target.value === "Entrega") {
        taxaEntrega = 5.00;
        if (grupoEndereco) grupoEndereco.style.display = "block";
      } else {
        taxaEntrega = 0;
        if (grupoEndereco) grupoEndereco.style.display = "none";
      }
      renderizarCarrinho();
    });
  });

  // Envio do formulário
  if (formPedido) {
    formPedido.addEventListener("submit", async e => {
      e.preventDefault();
      const itens = Carrinho.obter();
      if (itens.length === 0) {
        mostrarToast("Adicione produtos ao carrinho antes de finalizar.", "erro");
        return;
      }

      const formData = new FormData(formPedido);
      const nome = formData.get("nome");
      const telefone = formData.get("telefone");
      const tipoEntrega = formData.get("tipoEntrega") || "Retirada";
      const observacao = formData.get("observacao") || "";
      const endereco = formData.get("endereco") || "";

      const observacaoFinal = tipoEntrega === "Entrega" && endereco
        ? `Endereço: ${endereco}. ${observacao}`.trim()
        : observacao;

      const payload = {
        nome,
        telefone,
        tipoEntrega,
        observacao: observacaoFinal,
        itens: itens.map(i => ({ id: i.id, quantidade: i.quantidade }))
      };

      const btnSubmit = document.getElementById("btn-finalizar-pedido");
      const textoOriginal = btnSubmit.innerHTML;
      btnSubmit.disabled = true;
      btnSubmit.innerHTML = `⏳ Registrando pedido...`;

      try {
        const res = await requisicaoAPI("/orders", {
          method: "POST",
          body: JSON.stringify(payload)
        });

        mostrarToast(`Pedido #${res.pedido.id} registrado com sucesso! 🎉`);
        HistoricoLocal.adicionar(res.pedido);
        Carrinho.limpar();
        formPedido.reset();

        renderizarCarrinho();
        renderizarRecentes();
        abrirModalQR(res.pedido);

      } catch (erro) {
        mostrarToast(erro.message, "erro");
      } finally {
        btnSubmit.disabled = false;
        btnSubmit.innerHTML = textoOriginal;
      }
    });
  }

  renderizarCarrinho();
  renderizarRecentes();
}

// ============================================================================
// Inicializador: Página Pedidos Registrados (pedidos-registrados.html)
// ============================================================================
export async function iniciarPedidosRegistrados() {
  Carrinho.atualizarInterface();
  configurarModalQR();

  const gridEl = document.getElementById("grid-pedidos-registrados");
  const inputBusca = document.getElementById("busca-pedido-id");
  const selectStatus = document.getElementById("filtro-entrega");
  const btnAtualizar = document.getElementById("btn-recarregar-pedidos");
  const statTotal = document.getElementById("stat-total-pedidos");
  const statFaturamento = document.getElementById("stat-faturamento");
  const statRecebidos = document.getElementById("stat-recebidos");

  if (!gridEl) return;

  let pedidos = [];
  let tracker = new LateTracker([]);

  const renderizar = () => {
    let lista = tracker.listar();
    const termo = (inputBusca?.value || "").trim().toLowerCase();
    const filtroEntrega = selectStatus?.value || "todos";

    if (termo) {
      if (!isNaN(termo) && termo.length > 0) {
        const encontrado = tracker.encontrar(Number(termo));
        lista = encontrado ? [encontrado] : [];
      } else {
        lista = lista.filter(p =>
          p.nome.toLowerCase().includes(termo) ||
          p.telefone.includes(termo)
        );
      }
    }

    if (filtroEntrega !== "todos") {
      lista = lista.filter(p => p.tipoEntrega === filtroEntrega);
    }

    // Atualiza métricas
    if (statTotal) statTotal.textContent = pedidos.length;
    if (statFaturamento) {
      const soma = pedidos.reduce((acc, p) => acc + (p.total || 0), 0);
      statFaturamento.textContent = formatarMoeda(soma);
    }
    if (statRecebidos) {
      statRecebidos.textContent = pedidos.filter(p => p.status === "Recebido").length;
    }

    if (lista.length === 0) {
      gridEl.innerHTML = `
        <div class="estado-vazio" style="grid-column: 1/-1;">
          <span class="icone-vazio">📋</span>
          <h3>Nenhum pedido encontrado</h3>
          <p>Não há pedidos registrados correspondentes ao filtro atual.</p>
        </div>
      `;
      return;
    }

    gridEl.innerHTML = lista.map(p => `
      <article class="card-pedido-registrado">
        <div class="pedido-header">
          <span class="pedido-id">#${p.id}</span>
          <span class="status-badge ${p.tipoEntrega === 'Entrega' ? 'status-entrega' : 'status-recebido'}">
            <span class="status-ponto"></span>${escapar(p.tipoEntrega)} • ${escapar(p.status || "Recebido")}
          </span>
        </div>

        <div class="pedido-cliente">
          <strong>${escapar(p.nome)}</strong>
          <small>📞 ${escapar(p.telefone)} • 🕒 ${formatarData(p.criadoEm)}</small>
          ${p.observacao ? `<p style="margin-top:6px; font-size:0.84rem; color:var(--ink-secondary);"><em>"${escapar(p.observacao)}"</em></p>` : ''}
        </div>

        <div class="pedido-itens-resumo">
          <span style="font-size:0.78rem; font-weight:700; color:var(--ink-muted); text-transform:uppercase; display:block; margin-bottom:6px;">
            Itens do Pedido (${p.itens ? p.itens.reduce((acc, i) => acc + i.quantidade, 0) : 0}):
          </span>
          <div>
            ${(p.itens || []).map(i => `
              <span class="chip-item">${i.quantidade}x ${escapar(i.nome)}</span>
            `).join("")}
          </div>
        </div>

        <div class="pedido-rodape-card">
          <div>
            <small style="display:block; font-size:0.74rem; text-transform:uppercase; color:var(--ink-muted);">Total do Pedido</small>
            <span class="pedido-total-valor">${formatarMoeda(p.total)}</span>
          </div>
          <button class="botao botao-outline botao-pequeno" data-ver-qr="${p.id}">
            📱 QR Code
          </button>
        </div>
      </article>
    `).join("");

    gridEl.querySelectorAll("[data-ver-qr]").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = Number(btn.dataset.verQr);
        const pedido = tracker.encontrar(id);
        if (pedido) abrirModalQR(pedido);
      });
    });
  };

  const carregar = async () => {
    try {
      gridEl.innerHTML = `
        <div class="estado-vazio" style="grid-column: 1/-1;">
          <span class="icone-vazio">⏳</span>
          <h3>Carregando pedidos da API...</h3>
        </div>
      `;
      const res = await requisicaoAPI("/orders");
      pedidos = res.pedidos || [];
      tracker = new LateTracker(pedidos);
      renderizar();
    } catch (erro) {
      gridEl.innerHTML = `
        <div class="estado-vazio" style="grid-column: 1/-1;">
          <span class="icone-vazio">⚠️</span>
          <h3>Não foi possível conectar à API</h3>
          <p>${escapar(erro.message)}</p>
        </div>
      `;
    }
  };

  if (inputBusca) inputBusca.addEventListener("input", renderizar);
  if (selectStatus) selectStatus.addEventListener("change", renderizar);
  if (btnAtualizar) {
    btnAtualizar.addEventListener("click", () => {
      btnAtualizar.style.transform = "rotate(180deg)";
      setTimeout(() => btnAtualizar.style.transform = "none", 400);
      carregar();
    });
  }

  carregar();
}

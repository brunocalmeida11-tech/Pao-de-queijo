// Módulo de apoio reservado para integração futura com leitura de QR Code.
export function verificarDisponibilidade() { return false; }

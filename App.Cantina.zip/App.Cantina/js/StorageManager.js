// A API guarda os pedidos no arquivo data/pedidos.json. Este módulo ajuda a tratar respostas JSON.
export async function lerResposta(resposta) {
  const dados = await resposta.json();
  if (!resposta.ok) throw new Error(dados.erro || "Erro na requisição");
  return dados;
}

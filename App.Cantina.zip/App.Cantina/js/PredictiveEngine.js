export class PredictiveEngine {
  ordenarPorPopularidade(produtos, pedidos) {
    const vendas = {};
    for (const pedido of pedidos) for (const item of pedido.itens || []) vendas[item.id] = (vendas[item.id] || 0) + item.quantidade;
    return [...produtos].sort((a, b) => (vendas[b.id] || 0) - (vendas[a.id] || 0));
  }
}

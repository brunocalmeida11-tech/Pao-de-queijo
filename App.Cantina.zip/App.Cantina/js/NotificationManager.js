export class NotificationManager {
  sucesso(mensagem) { return { tipo: "sucesso", mensagem }; }
  erro(mensagem) { return { tipo: "erro", mensagem }; }
}

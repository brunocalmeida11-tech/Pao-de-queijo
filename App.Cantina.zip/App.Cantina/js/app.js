// Este arquivo roda como servidor da API no Node.js e como interface no navegador.
const PRODUTOS = [
  { id: 1, nome: "Pão de queijo tradicional", descricao: "Douradinho por fora e macio por dentro.", preco: 4, icone: "🧀", imagem: "img/pao_tradicional.jpg" },
  { id: 2, nome: "Pão de queijo recheado", descricao: "Com recheio cremoso de requeijão.", preco: 6.5, icone: "🥯", imagem: "img/pao_recheado.jpg" },
  { id: 3, nome: "Combo com 6 unidades", descricao: "Seis unidades para compartilhar.", preco: 20, icone: "🧺", imagem: "img/combo_seis.jpg" },
  { id: 4, nome: "Pão de queijo mini", descricao: "Pequeno e cheio de sabor.", preco: 2.5, icone: "✨", imagem: "img/pao_mini.jpg" },
  { id: 5, nome: "Combo café da manhã", descricao: "Três pães de queijo e um café.", preco: 15, icone: "☕", imagem: "img/combo_cafe.jpg" },
  { id: 6, nome: "Pão de queijo especial", descricao: "Uma opção especial para seu lanche.", preco: 7, icone: "🌟", imagem: "img/pao_especial.jpg" }
];

if (typeof window === "undefined") {
  const { createServer } = await import("node:http");
  const { readFile, writeFile, mkdir } = await import("node:fs/promises");
  const { existsSync } = await import("node:fs");
  const { join, extname, normalize } = await import("node:path");
  const PORT = Number(process.env.PORT || 3000);
  const ROOT = process.cwd();
  const DATA_DIR = join(ROOT, "data");
  const DATA_FILE = join(DATA_DIR, "pedidos.json");
  let pedidos = [];
  try { pedidos = JSON.parse(await readFile(DATA_FILE, "utf8")); } catch { pedidos = []; }
  const salvar = async () => { await mkdir(DATA_DIR, { recursive: true }); await writeFile(DATA_FILE, JSON.stringify(pedidos, null, 2)); };
  const enviar = (res, status, dados) => { res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "GET,POST,OPTIONS" }); res.end(JSON.stringify(dados)); };
  const tipos = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".webp": "image/webp"
  };
  createServer(async (req, res) => {
    if (req.method === "OPTIONS") { res.writeHead(204, { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "GET,POST,OPTIONS" }); return res.end(); }
    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    try {
      if (url.pathname === "/api/health" && req.method === "GET") return enviar(res, 200, { status: "ok", mensagem: "API de pedidos de pão de queijo funcionando" });
      if (url.pathname === "/api/products" && req.method === "GET") return enviar(res, 200, { total: PRODUTOS.length, produtos: PRODUTOS });
      if (url.pathname.startsWith("/api/products/") && req.method === "GET") {
        const id = Number(url.pathname.split("/").pop()); const produto = PRODUTOS.find(p => p.id === id);
        return produto ? enviar(res, 200, produto) : enviar(res, 404, { erro: "Produto não encontrado" });
      }
      if (url.pathname === "/api/orders" && req.method === "GET") return enviar(res, 200, { total: pedidos.length, pedidos });
      if (url.pathname === "/api/orders" && req.method === "POST") {
        let corpo = "";
        for await (const parte of req) corpo += parte;
        let dados;
        try { dados = JSON.parse(corpo || "{}"); } catch { return enviar(res, 400, { erro: "JSON inválido" }); }
        const nome = String(dados.nome || "").trim();
        const telefone = String(dados.telefone || "").trim();
        if (!nome || !telefone || !Array.isArray(dados.itens) || dados.itens.length === 0) return enviar(res, 400, { erro: "Informe nome, telefone e pelo menos um produto." });
        const itens = [];
        for (const item of dados.itens) {
          const produto = PRODUTOS.find(p => p.id === Number(item.id));
          const quantidade = Number(item.quantidade);
          if (!produto || !Number.isInteger(quantidade) || quantidade < 1 || quantidade > 99) return enviar(res, 400, { erro: "Produto ou quantidade inválida." });
          itens.push({ id: produto.id, nome: produto.nome, quantidade, preco: produto.preco });
        }
        const total = itens.reduce((soma, item) => soma + item.preco * item.quantidade, 0);
        const pedido = { id: pedidos.length ? Math.max(...pedidos.map(p => p.id)) + 1 : 1, nome, telefone, tipoEntrega: dados.tipoEntrega === "Entrega" ? "Entrega" : "Retirada", observacao: String(dados.observacao || "").slice(0, 250), itens, total: Number(total.toFixed(2)), status: "Recebido", criadoEm: new Date().toISOString() };
        pedidos.unshift(pedido); await salvar();
        return enviar(res, 201, { mensagem: "Pedido criado com sucesso", pedido });
      }
      if (url.pathname.startsWith("/api/orders/") && req.method === "GET") {
        const id = Number(url.pathname.split("/").pop()); const pedido = pedidos.find(p => p.id === id);
        return pedido ? enviar(res, 200, pedido) : enviar(res, 404, { erro: "Pedido não encontrado" });
      }
      // Entrega os arquivos do site pelo mesmo servidor.
      if (req.method === "GET") {
        let pathname = decodeURIComponent(url.pathname === "/" ? "/index.html" : url.pathname);
        pathname = normalize(pathname).replace(/^(\.\.[/\\])+/, "");
        let caminho = join(ROOT, pathname);
        if (!existsSync(caminho) && existsSync(caminho + ".html")) {
          caminho = caminho + ".html";
        }
        if (caminho.startsWith(ROOT) && existsSync(caminho)) {
          const conteudo = await readFile(caminho);
          res.writeHead(200, { "Content-Type": tipos[extname(caminho)] || "application/octet-stream" }); return res.end(conteudo);
        }
      }
      return enviar(res, 404, { erro: "Rota não encontrada" });
    } catch (erro) { console.error(erro); return enviar(res, 500, { erro: "Erro interno da API" }); }
  }).listen(PORT, () => console.log(`API do Pão de Queijo rodando em http://localhost:${PORT}`));
} else {
  const API = "http://localhost:3000/api";
  const moeda = valor => Number(valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  const escapar = texto => String(texto).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[c]));
  let produtos = [], carrinho = [];
  const $ = seletor => document.querySelector(seletor);
  async function requisicao(caminho, opcoes = {}) {
    const resposta = await fetch(`${API}${caminho}`, { ...opcoes, headers: { "Content-Type": "application/json", ...(opcoes.headers || {}) } });
    const dados = await resposta.json();
    if (!resposta.ok) throw new Error(dados.erro || "Não foi possível acessar a API.");
    return dados;
  }
  function mensagem(texto, tipo = "sucesso") { $("#mensagem").textContent = texto; $("#mensagem").className = `mensagem ${tipo}`; }
  async function carregarProdutos() {
    const resultado = await requisicao("/products"); produtos = resultado.produtos;
    $("#lista-produtos").innerHTML = produtos.map(p => `<article class="produto"><div class="produto-icone">${p.icone}</div><h3>${escapar(p.nome)}</h3><p>${escapar(p.descricao)}</p><div class="produto-rodape"><span class="preco">${moeda(p.preco)}</span><button class="botao botao-adicionar" data-add="${p.id}">Adicionar +</button></div></article>`).join("");
    $("#lista-produtos").querySelectorAll("[data-add]").forEach(b => b.addEventListener("click", () => { const id = Number(b.dataset.add); const item = carrinho.find(i => i.id === id); if (item) item.quantidade++; else carrinho.push({ id, quantidade: 1 }); renderCarrinho(); }));
  }
  function renderCarrinho() {
    const quantidade = carrinho.reduce((s, i) => s + i.quantidade, 0);
    $("#contador-carrinho").textContent = `${quantidade} ${quantidade === 1 ? "item" : "itens"}`;
    const total = carrinho.reduce((s, i) => s + produtos.find(p => p.id === i.id).preco * i.quantidade, 0);
    $("#total-pedido").textContent = moeda(total);
    $("#itens-pedido").innerHTML = carrinho.length ? carrinho.map(i => { const p = produtos.find(x => x.id === i.id); return `<div class="linha-item"><div><strong>${escapar(p.nome)}</strong><p>${moeda(p.preco)} cada</p></div><div class="controles"><button data-less="${i.id}">−</button><span>${i.quantidade}</span><button data-more="${i.id}">+</button></div></div>`; }).join("") : '<p class="vazio">Seu carrinho está vazio.</p>';
    $("#itens-pedido").querySelectorAll("[data-less]").forEach(b => b.addEventListener("click", () => { const i = carrinho.find(x => x.id === Number(b.dataset.less)); i.quantidade--; carrinho = carrinho.filter(x => x.quantidade > 0); renderCarrinho(); }));
    $("#itens-pedido").querySelectorAll("[data-more]").forEach(b => b.addEventListener("click", () => { carrinho.find(x => x.id === Number(b.dataset.more)).quantidade++; renderCarrinho(); }));
  }
  async function carregarPedidos() {
    const resultado = await requisicao("/orders");
    $("#lista-pedidos").innerHTML = resultado.pedidos.length ? resultado.pedidos.map(p => `<article class="cartao-pedido"><strong>Pedido #${p.id} — ${escapar(p.nome)}</strong><p>${escapar(p.tipoEntrega)} • ${new Date(p.criadoEm).toLocaleString("pt-BR")}</p><p>${p.itens.reduce((s, i) => s + i.quantidade, 0)} item(ns) • ${moeda(p.total)}</p><span class="status">${escapar(p.status)}</span></article>`).join("") : '<p class="vazio">Nenhum pedido registrado na API.</p>';
  }
  $("#form-pedido").addEventListener("submit", async evento => {
    evento.preventDefault();
    if (!carrinho.length) return mensagem("Adicione pelo menos um produto.", "erro");
    const dados = Object.fromEntries(new FormData(evento.currentTarget));
    try {
      const resultado = await requisicao("/orders", { method: "POST", body: JSON.stringify({ ...dados, itens: carrinho }) });
      mensagem(`Pedido #${resultado.pedido.id} registrado pela API!`);
      carrinho = []; evento.currentTarget.reset(); renderCarrinho(); await carregarPedidos();
    } catch (erro) { mensagem(erro.message, "erro"); }
  });
  $("#atualizar-pedidos").addEventListener("click", () => carregarPedidos().catch(e => mensagem(e.message, "erro")));
  Promise.all([carregarProdutos(), carregarPedidos()]).then(renderCarrinho).catch(erro => {
    $("#lista-produtos").innerHTML = `<p class="vazio">Não foi possível conectar à API. Inicie o servidor com <code>npm start</code>. (${escapar(erro.message)})</p>`;
  });
}

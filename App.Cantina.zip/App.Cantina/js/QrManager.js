export class QrManager {
  dadosPedido(pedido) { return JSON.stringify({ id: pedido.id, total: pedido.total, status: pedido.status }); }
}

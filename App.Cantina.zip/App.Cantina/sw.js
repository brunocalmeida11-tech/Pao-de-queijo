// Service Worker simples: a API continua sendo executada pelo servidor Node.js.
self.addEventListener("install", event => self.skipWaiting());
self.addEventListener("activate", event => event.waitUntil(self.clients.claim()));

# Pão de Queijo API 🧀

Aplicação simples para uma cantina vender pão de queijo. Backend em Python/Flask, banco SQLite e frontend HTML/CSS/JavaScript.

## Executar no Windows
```powershell
py -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
python seed.py
python -m app
```
Abra http://127.0.0.1:5000.

## Executar testes
```powershell
pytest -q
```

## Rotas
- `GET /api/health` — status da API
- `GET /api/products` — lista produtos; aceita `?q=termo`
- `GET /api/products/<id>` — consulta produto
- `POST /api/products` — cadastra produto
- `PATCH /api/products/<id>/stock` — atualiza estoque
- `GET /api/orders` — lista os últimos pedidos
- `GET /api/orders/<id>` — consulta pedido
- `POST /api/orders` — cria pedido e desconta o estoque

Exemplo de pedido:
```json
{"customer_name":"Bruno","items":[{"product_id":1,"quantity":2}],"notes":"Retirar no intervalo"}
```

Os preços e o estoque são conferidos no servidor. O projeto é uma demonstração e não possui login ou pagamento real.

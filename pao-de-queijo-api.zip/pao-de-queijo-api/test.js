const fs = require('fs');
const assert = require('assert');
assert(fs.existsSync('index.html'));
assert(fs.existsSync('static/js/app.js'));
assert(fs.existsSync('static/css/style.css'));
assert(fs.readFileSync('index.html','utf8').includes('Pão de Queijo'));
console.log('Testes básicos do frontend passaram!');

from app.db import connect_db, init_db
products=[
 ("Pão de Queijo Tradicional","Casquinha crocante e interior macio.",4.50,40,"🧀"),
 ("Pão de Queijo Recheado","Recheado com requeijão cremoso.",6.50,25,"🥯"),
 ("Mini Pão de Queijo (6 un.)","Porção para dividir com os amigos.",9.00,20,"🧺"),
 ("Combo Café da Manhã","Pão de queijo tradicional e café.",8.50,15,"☕")
]
if __name__=="__main__":
 init_db()
 with connect_db() as c:
  for name,desc,price,stock,image in products:
   if not c.execute("SELECT id FROM products WHERE name=?",(name,)).fetchone():
    c.execute("INSERT INTO products(name,description,price_cents,stock,image) VALUES(?,?,?,?,?)",(name,desc,round(price*100),stock,image))
 print("Banco preparado com os produtos iniciais.")

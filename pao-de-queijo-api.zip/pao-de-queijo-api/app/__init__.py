from flask import Flask, send_from_directory
from flask_cors import CORS
from .db import init_db
from .routes import api

def create_app(test_config=None):
    app = Flask(__name__)
    app.config.update(SECRET_KEY="dev-only-change-me", DATABASE="cantina.db")
    if test_config:
        app.config.update(test_config)
    CORS(app)
    init_db(app.config["DATABASE"])
    app.register_blueprint(api, url_prefix="/api")
    @app.get("/")
    def home():
        return send_from_directory(app.root_path + "/..", "index.html")
    return app

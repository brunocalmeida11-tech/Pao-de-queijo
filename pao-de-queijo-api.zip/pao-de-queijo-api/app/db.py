import sqlite3

def connect_db(path="cantina.db"):
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db(path="cantina.db"):
    with connect_db(path) as conn:
        conn.executescript('''
        CREATE TABLE IF NOT EXISTS products (
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          description TEXT NOT NULL DEFAULT '', price_cents INTEGER NOT NULL CHECK(price_cents>=0),
          stock INTEGER NOT NULL DEFAULT 0 CHECK(stock>=0), image TEXT NOT NULL DEFAULT '🧀',
          active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS orders (
          id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT NOT NULL,
          notes TEXT NOT NULL DEFAULT '', total_cents INTEGER NOT NULL CHECK(total_cents>=0),
          status TEXT NOT NULL DEFAULT 'confirmed', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS order_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
          product_id INTEGER NOT NULL REFERENCES products(id), product_name TEXT NOT NULL,
          quantity INTEGER NOT NULL CHECK(quantity>0), unit_price_cents INTEGER NOT NULL,
          subtotal_cents INTEGER NOT NULL
        );
        ''')

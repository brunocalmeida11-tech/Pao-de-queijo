import pytest
from . import create_app
@pytest.fixture()
def client(tmp_path):
    app=create_app({"TESTING":True,"DATABASE":str(tmp_path/"test.db")})
    with app.test_client() as c: yield c
def test_health(client):
    r=client.get("/api/health"); assert r.status_code==200 and r.json["status"]=="ok"
def test_order_updates_stock(client):
    p=client.post("/api/products",json={"name":"Pão","price":2.5,"stock":5}).json
    r=client.post("/api/orders",json={"customer_name":"Teste","items":[{"product_id":p["id"],"quantity":2}]})
    assert r.status_code==201 and r.json["total"]==5
    assert client.get(f'/api/products/{p["id"]}').json["stock"]==3
def test_insufficient_stock(client):
    p=client.post("/api/products",json={"name":"Pão","price":2,"stock":1}).json
    r=client.post("/api/orders",json={"customer_name":"Teste","items":[{"product_id":p["id"],"quantity":2}]})
    assert r.status_code==409

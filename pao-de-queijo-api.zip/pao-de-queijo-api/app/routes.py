from flask import Blueprint, jsonify, request, current_app
from .db import connect_db
api=Blueprint("api",__name__)
def db(): return connect_db(current_app.config["DATABASE"])
def product_json(p):
    return {"id":p["id"],"name":p["name"],"description":p["description"],"price":p["price_cents"]/100,"price_cents":p["price_cents"],"stock":p["stock"],"image":p["image"],"active":bool(p["active"])}
def order_json(conn, oid):
    o=conn.execute("SELECT * FROM orders WHERE id=?",(oid,)).fetchone()
    items=conn.execute("SELECT * FROM order_items WHERE order_id=?",(oid,)).fetchall()
    return {"id":o["id"],"customer_name":o["customer_name"],"notes":o["notes"],"total":o["total_cents"]/100,"status":o["status"],"created_at":o["created_at"],"items":[{"product_id":i["product_id"],"name":i["product_name"],"quantity":i["quantity"],"unit_price":i["unit_price_cents"]/100,"subtotal":i["subtotal_cents"]/100} for i in items]}
@api.get("/health")
def health(): return jsonify(status="ok",message="Pão de Queijo API online")
@api.get("/products")
def products():
    q=request.args.get("q","").strip()
    with db() as c:
        rows=c.execute("SELECT * FROM products WHERE active=1 AND (name LIKE ? OR description LIKE ?) ORDER BY id",(f"%{q}%",f"%{q}%")).fetchall()
    return jsonify([product_json(r) for r in rows])
@api.get("/products/<int:pid>")
def get_product(pid):
    with db() as c: p=c.execute("SELECT * FROM products WHERE id=? AND active=1",(pid,)).fetchone()
    if not p: return jsonify(error="Produto não encontrado"),404
    return jsonify(product_json(p))
@api.post("/products")
def create_product():
    d=request.get_json(silent=True) or {}
    name=str(d.get("name","")).strip()
    try: price=float(d.get("price")); stock=int(d.get("stock",0))
    except (ValueError,TypeError): return jsonify(error="Preço e estoque devem ser números válidos"),400
    if not name or price<0 or stock<0: return jsonify(error="Informe nome, preço e estoque válidos"),400
    with db() as c:
        cur=c.execute("INSERT INTO products(name,description,price_cents,stock,image) VALUES(?,?,?,?,?)",(name,str(d.get("description","")).strip(),round(price*100),stock,str(d.get("image","🧀"))))
        p=c.execute("SELECT * FROM products WHERE id=?",(cur.lastrowid,)).fetchone()
    return jsonify(product_json(p)),201
@api.patch("/products/<int:pid>/stock")
def stock(pid):
    d=request.get_json(silent=True) or {}
    try: qty=int(d.get("quantity"))
    except (ValueError,TypeError): return jsonify(error="Quantidade inválida"),400
    if qty<0: return jsonify(error="Estoque não pode ser negativo"),400
    with db() as c:
        cur=c.execute("UPDATE products SET stock=? WHERE id=? AND active=1",(qty,pid))
        p=c.execute("SELECT * FROM products WHERE id=? AND active=1",(pid,)).fetchone()
    if cur.rowcount==0: return jsonify(error="Produto não encontrado"),404
    return jsonify(product_json(p))
@api.post("/orders")
def create_order():
    d=request.get_json(silent=True) or {}; customer=str(d.get("customer_name","")).strip(); items=d.get("items")
    if not customer: return jsonify(error="Informe o nome do cliente"),400
    if not isinstance(items,list) or not items: return jsonify(error="Pedido precisa ter itens"),400
    conn=db()
    try:
        conn.execute("BEGIN IMMEDIATE")
        quantities={}
        for item in items:
            try: pid=int(item["product_id"]); qty=int(item["quantity"])
            except (ValueError,TypeError,KeyError): conn.rollback(); return jsonify(error="Item inválido"),400
            if qty<1: conn.rollback(); return jsonify(error="Quantidade deve ser maior que zero"),400
            quantities[pid]=quantities.get(pid,0)+qty
        resolved=[]; total=0
        for pid,qty in quantities.items():
            p=conn.execute("SELECT * FROM products WHERE id=? AND active=1",(pid,)).fetchone()
            if not p: conn.rollback(); return jsonify(error=f"Produto {pid} não encontrado"),404
            if p["stock"]<qty: conn.rollback(); return jsonify(error=f"Estoque insuficiente para {p['name']}",available=p["stock"]),409
            sub=p["price_cents"]*qty; total+=sub; resolved.append((p,qty,sub))
        cur=conn.execute("INSERT INTO orders(customer_name,notes,total_cents) VALUES(?,?,?)",(customer,str(d.get("notes","")).strip(),total))
        oid=cur.lastrowid
        for p,qty,sub in resolved:
            conn.execute("UPDATE products SET stock=stock-? WHERE id=?",(qty,p["id"]))
            conn.execute("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price_cents,subtotal_cents) VALUES(?,?,?,?,?,?)",(oid,p["id"],p["name"],qty,p["price_cents"],sub))
        conn.commit()
        return jsonify(order_json(conn,oid)),201
    except Exception:
        conn.rollback(); current_app.logger.exception("Falha ao criar pedido")
        return jsonify(error="Não foi possível registrar o pedido"),500
    finally: conn.close()
@api.get("/orders")
def orders():
    with db() as c: ids=c.execute("SELECT id FROM orders ORDER BY id DESC LIMIT 100").fetchall()
    with db() as c: return jsonify([order_json(c,r["id"]) for r in ids])
@api.get("/orders/<int:oid>")
def get_order(oid):
    with db() as c:
        row=c.execute("SELECT id FROM orders WHERE id=?",(oid,)).fetchone()
        if not row: return jsonify(error="Pedido não encontrado"),404
        return jsonify(order_json(c,oid))
